/** Automatically generated file. DO NOT MODIFY */
package jp.example.bluetooth_01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}